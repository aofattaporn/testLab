package tile;

public class Bomb {

    int col;
    int row;

    public Bomb(int col, int row) {
        this.col = col;
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }
}
